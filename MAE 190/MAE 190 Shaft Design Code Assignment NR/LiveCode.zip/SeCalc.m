function Se = SeCalc(Sut,ka,kb,kc,kd,ke,kf)
    Se = ka*kb*kc*kd*ke*kf*0.5*Sut;
end