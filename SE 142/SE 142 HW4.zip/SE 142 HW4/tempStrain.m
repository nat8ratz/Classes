function Eo = tempStrain(a,Nt)
    Eo = a*Nt;
end